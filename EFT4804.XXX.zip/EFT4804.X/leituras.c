/*
 * File:   VFonte.c
 * Author: caio
 *
 * Created on September 5, 2022, 10:08 AM
 */

#include "mcc_generated_files/mcc.h"
#include <xc.h>


