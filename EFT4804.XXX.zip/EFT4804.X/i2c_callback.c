/*
 * File:   i2c_callback.c
 * Author: dh056256
 *
 * Created on October 9, 2023, 5:54 PM
 */


#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/i2c1_slave.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

uint8_t buffer = 0;
bool send = false;

uint8_t txBuffer[15];
uint8_t rxBuffer[15];
uint8_t count = 0;
uint8_t refBufferProtocol[] = {0x45, 0x46, 0x54, 0x34, 0x38, 0x30, 0x34, 0x44,0xff,0xff,0x00};
uint8_t index = 0;

size_t lenRef = sizeof (refBufferProtocol);

size_t tamanhoArray = sizeof(refBufferProtocol);

size_t tamanhoElemento = sizeof(refBufferProtocol[0]);


uint8_t calcularChecksun(uint8_t tamanho,uint8_t array[])
{
    uint8_t checksun=0;
    
    for(size_t i =0; i<tamanho; i++)
    {
        checksun+= array[i];
    }
    
    return checksun;
}



void I2C1_SlaveSendTxData(size_t len, uint8_t *data) {
    
    I2C1_Write(data[index]);
    I2C1_SendAck();
    index = index + 1;
    if (index >len) {
        index = 0;

    }
}

void ControleState(void) {


    switch (rxBuffer[0]) {

        case 0x27:

            send = true;
            count = 0;
            break;
        case 0x28:
            //YELLOW_Toggle();
           // refBufferProtocol[7] = 0x4C;
            send = true;
            count = 0;
            break;
        case 0x66:
            //I2C1_Write("\n");
            send = false;
            count = 0;
            break;

    }


}

static void I2C1_ReadCallback() {

    rxBuffer[count] = I2C1_Read();
    I2C1_SendAck();
    count++;

    ControleState();


}

static void I2C1_WriteCallback() {

    if (send == true) {
        size_t quantidade = (tamanhoArray) / (tamanhoElemento);
        
        //refBufferProtocol[9]= calcularChecksun(tamanhoArray,refBufferProtocol);
        
        I2C1_SlaveSendTxData(quantidade, refBufferProtocol);
    }else
    {
        
    }


}

static void I2C1_AddressCallback() {
    uint8_t buf = SSP1BUF;
    I2C1_SendAck();
}

static void I2C1_WriteColCallback() {

}

static void I2C1_BusColCallback() {


}

void I2C1_Init() {
    I2C1_Open();
    I2C1_SlaveSetBusColIntHandler(I2C1_BusColCallback);
    I2C1_SlaveSetWriteIntHandler(I2C1_WriteCallback);
    I2C1_SlaveSetReadIntHandler(I2C1_ReadCallback);
    I2C1_SlaveSetAddrIntHandler(I2C1_AddressCallback);
    I2C1_SlaveSetWrColIntHandler(I2C1_WriteColCallback);

}