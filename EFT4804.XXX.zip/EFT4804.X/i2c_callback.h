/* 
 * File:   i2c_callback.h
 * Author: dh056256
 *
 * Created on 10 de Outubro de 2023, 14:00
 */

#ifndef I2C_CALLBACK_H
#define	I2C_CALLBACK_H

#ifdef	__cplusplus
extern "C" {
#endif

void I2C1_Init();

#ifdef	__cplusplus
}
#endif

#endif	/* I2C_CALLBACK_H */

