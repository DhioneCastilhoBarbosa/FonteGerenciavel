/* 
 * File:   main.h
 * Author: dh056256
 *
 * Created on 11 de Outubro de 2023, 09:17
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

void desativaBAT();
float tensaoVFONTE, tensaoVBAT, corrente = 0;

#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

