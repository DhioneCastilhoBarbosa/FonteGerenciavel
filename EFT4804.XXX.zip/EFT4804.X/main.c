/*
 * Modelo da fonte: EFT4804
 * Modelo do PIC: pic16F15344
 * Data: 20/12/2022
 */

/* (bit)  (V)
 * 502 == 55
 * 465 == 51
 * 438 == 48
 * 410 == 45V
 * 383 == 42V
 */
#include "mcc_generated_files/mcc.h"
#include "i2c_callback.h"
#include<stdbool.h>
// configura��es
int filtroAtivo = 1;

// +100mA = +30bit
int corrente35 = 580; // 810 = 5A
int corrente37 = 640;
int corrente38 = 670;
int corrente40 = 730;

int tensaoBat55 = 730;
int tensaoBat54 = 720;
int tensaoBat50 = 660;
int tensaoBat48 = 640;
int tensaoBat46 = 610;
int tensaoBat42 = 560;

int tensaoVfonteMax = 502;

float tensaoVFONTE, tensaoVBAT, corrente = 0;
int botaoEstado, botaoPressionado = 0;
int botao2Estado, botao2Pressionado = 0;

// VARI�VEIS DE ESTADO
bool tensaoVCA = false;
bool stop = false;
bool firstLoop = true;
bool erroBAT = false;
bool erroCorrente40 = false;
bool modoBAT = false;
bool saiuDoReset = false;
bool Load = false;





void sinalizaBAT() {
    GREEN_SetLow();
    modoBAT = true;
    // Desliga o LED vermelho se n�o tiver erro na corrente
    if (!erroCorrente40) {
        RED_SetLow();
    }
    // Somente se n�o tiver tens�o VCA:
    if (!tensaoVCA) {
        if (ADC_GetConversion(VBAT) > tensaoBat48) {
            YELLOW_SetHigh();
        } else if (ADC_GetConversion(VBAT) > tensaoBat46) {
            if (TMR2_HasOverflowOccured()) // PISCA 1 SEGUNDO         
            {
                YELLOW_Toggle(); //Switch state of D5 LED when overflow occurs
                TMR2IF = 0; //Clear the Timer0 overflow flag
            }
        } else if (ADC_GetConversion(VBAT) > tensaoBat42) { // MAIOR QUE 42V (500 BITS)
            if (TMR0_HasOverflowOccured()) // PISCA 0,2 SEGUNDO           
            {
                YELLOW_Toggle(); //Switch state of D5 LED when overflow occurs
                TMR0IF = 0; //Clear the Timer0 overflow flag
            }
        }
    }
}


void sinalizaOK() {
   
    GREEN_SetHigh();
    YELLOW_SetLow();
    modoBAT = false;
}
void sinalizaErro() {
    if (erroBAT) {
        if (TMR0_HasOverflowOccured()) //Has Timer0 Overflowed?            
        {
            RED_Toggle(); //Switch state of D5 LED when overflow occurs
            TMR0IF = 0; //Clear the Timer0 overflow flag
        }
    } else {
        RED_SetHigh();
    }
}

// FUNCTIONS GERAIS
void ativaBAT() {
    firstLoop = false;
    erroBAT = false;
    RELE_SetHigh();
    if (botaoEstado == 0) {
        __delay_ms(800);
    }
    if (saiuDoReset) {
        saiuDoReset = false;
        __delay_ms(100);
    }
}
void desativaBAT() {
    
    RELE_SetLow(); // DESATIVA BATERIA
    YELLOW_SetLow();
    modoBAT = false;
    erroBAT = true;
    sinalizaErro();
}
float filtro(float var, adc_channel_t pin) {
    var = ADC_GetConversion(pin);
    if (filtroAtivo) {
        var += ADC_GetConversion(pin);
        var += ADC_GetConversion(pin);
        var += ADC_GetConversion(pin);
        var += ADC_GetConversion(pin);
        var /= 5;
    }
    return var; // Retorna uma leitura filtrada da porta anal�gica correspondente.
}
void leitura() {
    tensaoVFONTE = filtro(tensaoVFONTE, VFONTE);
    tensaoVBAT = filtro(tensaoVBAT, VBAT);
    corrente = filtro(corrente, CORR);
    tensaoVCA = VCA_GetValue();
    // BOT�O        
    botaoEstado = CH_BAT_GetValue();
    botao2Estado = CH_BUZZER_GetValue();
    if (botaoEstado == 0) {
        __delay_ms(800);
        if (botaoPressionado)
            botaoPressionado = 0;
        else
            botaoPressionado = 1;
    }
    if (botao2Estado == 0) {
        __delay_ms(800);
        if (botao2Pressionado)
            botao2Pressionado = 0;
        else
            botao2Pressionado = 1;
    }
}


void overLoad()
{
    RED_SetHigh();
    RELE_SetLow();
    while (Load) 
    {   
        leitura();
        
        if (tensaoVCA){
                GREEN_SetHigh();
                YELLOW_SetLow();
            }
            else{
                GREEN_SetLow();
            }
        
        __delay_ms(2500);
        
        if (corrente <= corrente37 && tensaoVCA) {
          
           RED_SetLow();
           RELE_SetLow();   
           Load = false;   
           break;
        }   
        __delay_ms(2500); 
    }
    
}




// FUNCTIONS ESPECIFICAS
void verificaCorrente() 
{
    
    if (corrente > corrente37){ //3,7A
        if (corrente > corrente40) { //4,0A
            //stop = true;
            Load = true;
            overLoad();
            erroCorrente40 = true;
        } else {
            sinalizaErro();
            //ativaBAT();
            erroCorrente40 = false;
        }
    } else {
        if(Load == false )
        {
            ativaBAT();
            RED_SetLow();
            erroCorrente40 = false;
        }
    }
      
}



void testeBAT42() {
    if (tensaoVBAT > tensaoBat42) //42V
        verificaCorrente();
    else
        stop = true;
}
void testeBAT50() {
    if (tensaoVBAT > tensaoBat46) { //50V
        sinalizaBAT();
        verificaCorrente();
    } else
        stop = true;
}
void verificaModoBAT() {
    if (modoBAT) {
        if (botaoPressionado)
            stop = true;
        else{
            sinalizaBAT();
            testeBAT42();
        }
    } else {
        if (botaoPressionado) {
            stop = true;
        } else
            testeBAT50();
    }
}

// C�DIGO PRINCIPAL
void main(void) {
    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    SYSTEM_Initialize();
    I2C1_Init();
    
    while (1) {
        if (firstLoop)
            __delay_ms(100);
        // RESET DOS ESTADOS
        erroBAT = false;
        DESATIVA_SetLow();

        leitura();

        // DESLIGAR A FONTE
        if (botao2Pressionado) {
            botao2Pressionado = 0;
            DESATIVA_SetHigh();
            stop = true;
        }

        if (tensaoVCA) {
            sinalizaOK();
            if (botaoPressionado) {
                stop = true;
            } else
                testeBAT42();
        } else {
            if (firstLoop) {
                if (botaoPressionado) {
                    botaoPressionado = 0;
                    verificaModoBAT();
                } else {
                    erroBAT = true;
                    sinalizaErro();
                }
            } else {
                verificaModoBAT();
            }
        }
        while (stop) {
            botaoPressionado = 0;
            BUZZER_SetHigh();
            desativaBAT();
            leitura();
            if (tensaoVCA){
                GREEN_SetHigh();
            }
            else{
                GREEN_SetLow();
            }
            if (botaoPressionado) {
                BUZZER_SetLow();
                stop = false;
                botaoPressionado = 0;
                saiuDoReset = true;
                break;
            }
        }
    }
}
